package Skeleton.simulator;

public interface SimulationObject {
	void listParameters();
	String printName();
}
