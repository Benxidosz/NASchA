./build.sh

java -cp build Proto.Main -t -a
