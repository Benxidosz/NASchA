java -cp build Proto.Main
