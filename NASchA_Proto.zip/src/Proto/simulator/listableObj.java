package Proto.simulator;

/**
 * An interface which is list the listable objects.
 */
public interface listableObj {
	String List();
}
