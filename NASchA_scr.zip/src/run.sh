javac Skeleton/*.java Skeleton/controllers/*.java Skeleton/entities/*.java Skeleton/entities/children/*.java Skeleton/materials/*.java Skeleton/materials/children/*.java Skeleton/simulator/*.java Skeleton/things/*.java Skeleton/things/asteroids/*.java Skeleton/things/gate/*.java

java Skeleton/*.java Skeleton/controllers/*.java Skeleton/entities/*.java Skeleton/entities/children/*.java Skeleton/materials/*.java Skeleton/materials/children/*.java Skeleton/simulator/*.java Skeleton/things/*.java Skeleton/things/asteroids/*.java Skeleton/things/gate/*.java
