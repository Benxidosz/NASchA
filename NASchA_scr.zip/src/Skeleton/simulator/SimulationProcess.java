package Skeleton.simulator;

@FunctionalInterface
public interface SimulationProcess {
	void run();
}
